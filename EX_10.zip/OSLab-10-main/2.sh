#!/bin/bash


for iterator in {1..100}

do

	mkdir user$iterator

don
