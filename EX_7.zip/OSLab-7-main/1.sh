ln example.sh exampleS.sh
ln -s example.sh exampleSS.sh
