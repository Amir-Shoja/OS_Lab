sudo -s
sudo apt-get update
apt-get install vim
vi simple.txt
sudo apt-get install emacs
emac simple.txt         
sudo -s

