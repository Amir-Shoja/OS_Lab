chown
chown -v
chown -c
chown -R
gpasswd
gpasswd -h
gpasswd -r
gpasswd -M
