sudo groupadd sadjad
sudo groupadd Uni
sudo usermod -G sadjad,Uni oslab
sudo gpasswd -A oslab sadjad
