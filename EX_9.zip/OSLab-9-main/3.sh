sudo useradd oslab
sudo passwd oslab
