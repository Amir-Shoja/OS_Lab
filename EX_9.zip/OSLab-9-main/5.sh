sudo useradd os2
sudo usermod -G sadjad os2
sudo userdel os2
