id
id -u -n
whoami
id username
