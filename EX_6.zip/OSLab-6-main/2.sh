rar a simple.rar file -p
