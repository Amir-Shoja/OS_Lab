ls -r
ls -t -r
ls -S
