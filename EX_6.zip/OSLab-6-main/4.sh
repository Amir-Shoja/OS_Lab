nano -B
nano -D
nano -V
