git init
git add —all
git commit -m "first commit"
git remote add origin https://github.com/Amir-Shoja/OSLab-5.git
git branch -M main
git push -u origin main
