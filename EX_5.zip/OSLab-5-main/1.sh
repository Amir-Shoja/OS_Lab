git config --global user.name "Name"
git config --global user.password "Password"
