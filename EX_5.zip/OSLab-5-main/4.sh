systemd-analyze time
uptime
